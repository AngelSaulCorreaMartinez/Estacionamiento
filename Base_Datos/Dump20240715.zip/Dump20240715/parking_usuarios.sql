CREATE DATABASE  IF NOT EXISTS `parking` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `parking`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: parking
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `Correo` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Contraseña` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Nombre` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Apellido` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Fecha_Nacimiento` date NOT NULL,
  `Numero_Telefono` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Miembro_desde` date NOT NULL,
  PRIMARY KEY (`Correo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES ('bryan@gmail.com','123456789','jaz','ser','1111-12-12','35487','0003-12-03'),('bryan@gmail.com.mx','123456789','jaz','ser','1111-12-12','449','0003-12-03'),('bryandovavaz010882_@hotmail.com','88','bryan','dovalina','2024-07-12','6174951000','2024-07-12'),('jaz@utma.com.mx','12345','jaz','ser','1111-12-12','35487','0003-12-03'),('jaz@utma.com.mx.es','12345','jaz','ser','1111-12-12','35487','0003-12-03'),('jaz@utma.com.mx.es.c','12345','jaz','ser','1111-12-12','35487','0003-12-03'),('jaz@utma.com.mx.es.com','','jaz','ser','1111-12-12','35487','0003-12-03'),('jaz@utma.com.mx.es.com.css','','jaz','ser','1111-12-12','35487','0003-12-03'),('jaz@utma.com.mx.es.com.css.s','','jaz','ser','1111-12-12','35487','0003-12-03'),('jaz@utma.edu','1234','jaz','ser','1111-12-12','35487','0003-12-03'),('jaz@utma.edu.mx','kkck123','jaz','ser','1212-12-12','12121212','1212-12-12'),('jaz@utma.edu.mxx','kksk123','jaz','ser','1111-12-12','35487','0003-12-03'),('jaz@utma.edu.mxxx','kksk123','jaz','ser','1111-12-12','35487','0003-12-03'),('jaz@utma.es','12345','jaz','ser','1111-12-12','35487','0003-12-03'),('jaz@utma.mx','12345','jaz','ser','1111-12-12','35487','0003-12-03'),('jaz@utmaa.edu.mx','kkck123','jaz','ser','2323-02-04','12121212','0323-02-06'),('jaz@utmaaa.edu.mx','kkck123','jaz','ser','2323-02-04','12121212','0323-02-06'),('jaz@utmaaa.eedu.mx','kkck123','jaz','ser','2323-02-04','12121212','0323-02-06'),('jaz@utmaaa.eeedu.mx','kkck123','jaz','ser','2323-02-04','12121212','0323-02-06'),('jaz@utmaaa.eeeedu.mx','kkck123','jaz','ser','2323-02-04','12121212','0323-02-06'),('luna24@gmail.com','lu','luna','cortes ','1220-02-23','4495088283','1222-03-02'),('utm22030619@utma.edu.mx','plasma3d','bryan','dovalina','2004-02-21','6174951000','2004-02-21'),('utm22@com.com','44','Bryan','Dovalina','2024-07-12','4494494499','2024-07-12');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-15  9:19:54
